﻿Public Class frmAdd

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        'Closing Add application
        Me.Close()
    End Sub


    Private Sub lblDateOfNote_Click(sender As Object, e As EventArgs) Handles lblDateOfNote.Click
        '******************************************************************************************
        '* Show the Calendar
        '******************************************************************************************
        If IsDate(lblDateOfNote.Text) Then
            ' Pass the date to the Calendar if there is one
            frmCalendar.PassedInDate = CDate(lblDateOfNote.Text)
        End If
        'Call calendar form
        frmCalendar.ShowDialog()

        If IsDate(frmCalendar.PassedOutDate) Then
            lblDateOfNote.Text = Format(CDate(frmCalendar.PassedOutDate.ToString()), "MM/dd/yyyy hh:mm:ss tt")
        Else
            lblDateOfNote.Text = ""
        End If

        '************************************************************************************************
        '* End Show the Calendar
        '*************************************************************************************************
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click

        'Check if boxes are empty
        If Trim(lblDateOfNote.Text) = "" Then
            MsgBox("Please enter a Date of Note")
            lblDateOfNote_Click(sender, e)
            Exit Sub
        End If

        If Trim(txtNote.Text) = "" Then
            MsgBox("Please enter a Note")
            txtNote.Focus()
            Exit Sub
        End If

        If Trim(txtType.Text) = "" Then
            MsgBox("Please enter Type of Note")
            txtType.Focus()
            Exit Sub
        End If

        Dim AccessDataSet As New DataSet
        Dim AccessDataAdapter As OleDb.OleDbDataAdapter
        Dim sql As String
        Dim AccessConnection As New OleDb.OleDbConnection
        AccessConnection.ConnectionString = AccessConnectionString

        ' open the database connection
        AccessConnection.Open()

        sql = " INSERT INTO Tab_Notes_Header(Notes, Date_Of_Notes, Type_Of_Notes)" & _
              " VALUES ('" & Trim(txtNote.Text) & "','" & Trim(lblDateOfNote.Text) & "','" & Trim(txtType.Text) & "')"


        AccessDataAdapter = New OleDb.OleDbDataAdapter(sql, AccessConnection)
        AccessDataAdapter.Fill(AccessDataSet)

        ' close database connection
        AccessConnection.Close()

        ' Confirmation that new record has been added
        MsgBox("Note Added", vbOKOnly, "New Record Added")

        'Clearing variables. 
        txtNote.Clear()
        txtType.Clear()
        lblDateOfNote.Text = ""
        AccessDataAdapter = Nothing
        AccessConnection = Nothing

        'Closing Application affter adding
        Me.Close()

    End Sub

    Private Sub frmAdd_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'Setting todays date to Date Of note
        lblDateOfNote.Text = Format(CDate(Now.ToString()), "MM/dd/yyyy hh:mm:ss tt")
    End Sub
End Class