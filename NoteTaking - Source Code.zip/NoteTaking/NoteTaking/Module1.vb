﻿Imports System.Data.SqlClient
Imports System.Data.OleDb

Module Module1

    'Public apppatch As String = System.AppDomain.CurrentDomain.BaseDirectory()

    'Access Connection string. 
    Public AccessConnectionString As String = "PROVIDER = Microsoft.jet.OLEDB.4.0;Data Source =" & System.AppDomain.CurrentDomain.BaseDirectory() & "\Database\Note_Taking.mdb;Jet OLEDB:Database Password=5789231;"

End Module

