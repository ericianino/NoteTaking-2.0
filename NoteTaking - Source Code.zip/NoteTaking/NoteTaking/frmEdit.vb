﻿Imports System.Data.OleDb

Public Class frmEdit

    Public intNSAN As Integer

    Private Sub frmEdit_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        'Access Data Connection
        Dim AccessDataSet As New DataSet
        Dim AccessDataAdapter As OleDb.OleDbDataAdapter
        Dim sql As String
        Dim AccessConnection As New OleDb.OleDbConnection
        AccessConnection.ConnectionString = AccessConnectionString

        ' number of columns in the list view
        Dim strItemcoll(3) As String


        ' Select all notes
        sql = " SELECT *" & _
              " FROM Tab_Notes_Header" & _
              " WHERE NSAN = " & intNSAN

        'Opening access database
        AccessConnection.Open()

        AccessDataAdapter = New OleDb.OleDbDataAdapter(sql, AccessConnection)
        AccessDataAdapter.Fill(AccessDataSet)

        'close the database connection
        AccessConnection.Close()

        ' Adding the items into the listview
        For i = 0 To AccessDataSet.Tables(0).Rows.Count - 1

            lblDateOfNote.Text = Format(CDate(AccessDataSet.Tables(0).Rows(i)(2).ToString()), "MM/dd/yyyy hh:mm:ss tt")
            txtType.Text = AccessDataSet.Tables(0).Rows(i)(3).ToString()
            txtNote.Text = AccessDataSet.Tables(0).Rows(i)(1).ToString()

            'Date close yes or no. 
            If AccessDataSet.Tables(0).Rows(i)(1).ToString() <> "" Then
                rdbNo.Checked = True
            Else
                rdbNo.Checked = False
            End If
        Next

        'clean up
        AccessDataSet = Nothing
        AccessDataAdapter = Nothing
        AccessConnection = Nothing

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        'Closing edit screen
        Me.Close()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click

        Dim AccessDataSet As New DataSet
        Dim AccessDataAdapter As OleDb.OleDbDataAdapter
        '  Dim UpdateCommand As New OleDbCommand
        Dim sql As String
        Dim AccessConnection As New OleDb.OleDbConnection
        AccessConnection.ConnectionString = AccessConnectionString

        ' open the database connection
        AccessConnection.Open()
        '  UpdateCommand.Connection = AccessConnection

        If rdbYes.Checked = False Then

            sql = " UPDATE Tab_Notes_Header SET Notes = '" & Trim(txtNote.Text) & "'," & _
                                  " Date_Of_Notes = '" & Trim(lblDateOfNote.Text) & "'," & _
                                  " Type_Of_Notes = '" & Trim(txtType.Text) & "' " & _
                                  " WHERE NSAN = " & intNSAN
        Else

            sql = " UPDATE Tab_Notes_Header SET Notes = '" & Trim(txtNote.Text) & "'," & _
                                 " Date_Of_Notes = '" & Trim(lblDateOfNote.Text) & "'," & _
                                 " Date_Close_Of_Notes = '" & Trim(Now) & "'," & _
                                 " Type_Of_Notes = '" & Trim(txtType.Text) & "' " & _
                                 " WHERE NSAN = " & intNSAN

        End If



        AccessDataAdapter = New OleDb.OleDbDataAdapter(sql, AccessConnection)
        AccessDataAdapter.Fill(AccessDataSet)

        ' close database connection
        AccessConnection.Close()

        ' Clean up
        AccessDataSet = Nothing
        AccessDataAdapter = Nothing

        'Confirmation of Changes.
        MsgBox("Note Changed", vbOKOnly, "Change Note Record")

        'Back to listview. 
        btnExit_Click(sender, e)


    End Sub
End Class