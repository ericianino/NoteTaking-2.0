﻿Public Class frmView

    Public intNSAN As Integer

    Private Sub frmView_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'Access Data Connection
        Dim AccessDataSet As New DataSet
        Dim AccessDataAdapter As OleDb.OleDbDataAdapter
        Dim sql As String
        Dim AccessConnection As New OleDb.OleDbConnection
        AccessConnection.ConnectionString = AccessConnectionString

        ' number of columns in the list view
        Dim strItemcoll(3) As String


        ' Select all notes
        sql = " SELECT *" & _
              " FROM Tab_Notes_Header" & _
              " WHERE NSAN = " & intNSAN

        'Opening access database
        AccessConnection.Open()

        AccessDataAdapter = New OleDb.OleDbDataAdapter(sql, AccessConnection)
        AccessDataAdapter.Fill(AccessDataSet)

        'close the database connection
        AccessConnection.Close()

        ' Adding the items into the listview
        For i = 0 To AccessDataSet.Tables(0).Rows.Count - 1

            lblDateOfNote.Text = Format(CDate(AccessDataSet.Tables(0).Rows(i)(2).ToString()), "MM/dd/yyyy hh:mm:ss tt")
            txtType.Text = AccessDataSet.Tables(0).Rows(i)(3).ToString()
            txtNote.Text = AccessDataSet.Tables(0).Rows(i)(1).ToString()

        Next

        'clean up
        AccessDataSet = Nothing
        AccessDataAdapter = Nothing
        AccessConnection = Nothing

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs)

        'Closing View appliaction
        Me.Close()
    End Sub
End Class