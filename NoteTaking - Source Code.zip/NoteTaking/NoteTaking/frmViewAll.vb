﻿Public Class frmViewAll

    Private Sub ExitToolStripMenuItem_Click_1(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        'Closing Application
        Me.Close()
    End Sub

    Private Sub frmViewAll_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Load_ListView1()
    End Sub


    Public Sub Load_ListView1()

        'Access Data Connection
        Dim AccessDataSet As New DataSet
        Dim AccessDataAdapter As OleDb.OleDbDataAdapter
        Dim sql As String
        Dim AccessConnection As New OleDb.OleDbConnection
        Dim strEmpty As String = ""
        AccessConnection.ConnectionString = AccessConnectionString

        ' number of columns in the list view
        Dim strItemcoll(3) As String

        '  ChangeToolStripMenuItem.Enabled = False
        ' RemoveToolStripMenuItem.Enabled = False
        ViewToolStripMenuItem.Enabled = False

        ListView1.Items.Clear()
        ListView1.GridLines = True

        ' Select all notes

        sql = " SELECT * FROM Tab_Notes_Header Order By Date_Close_Of_notes asc "

        'Opening access database
        AccessConnection.Open()

        AccessDataAdapter = New OleDb.OleDbDataAdapter(sql, AccessConnection)
        AccessDataAdapter.Fill(AccessDataSet)

        'close the database connection
        AccessConnection.Close()

        ' Adding the items into the listview
        For i = 0 To AccessDataSet.Tables(0).Rows.Count - 1

            strItemcoll(0) = Format(CDate(AccessDataSet.Tables(0).Rows(i)(2).ToString()), "MM/dd/yyyy hh:mm:ss tt")
            strItemcoll(1) = AccessDataSet.Tables(0).Rows(i)(3).ToString()
            strItemcoll(2) = AccessDataSet.Tables(0).Rows(i)(1).ToString()


            strItemcoll(3) = AccessDataSet.Tables(0).Rows(i)(4).ToString()
            If IsDate(strItemcoll(3)) Then

                strItemcoll(3) = Format(CDate(AccessDataSet.Tables(0).Rows(i)(4).ToString()), "MM/dd/yyyy hh:mm:ss tt")
            End If

            Dim lvi As New ListViewItem(strItemcoll)
            lvi.Tag = AccessDataSet.Tables(0).Rows(i)(0).ToString
            ListView1.Items.Add(lvi)
        Next

        'clean up
        AccessDataSet = Nothing
        AccessDataAdapter = Nothing
        AccessConnection = Nothing

    End Sub


    Private Sub ViewToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ViewToolStripMenuItem.Click
        'sending SAN to View
        frmView.intNSAN = CInt(ListView1.FocusedItem.Tag.ToString)

        'Open View Form. 
        frmView.ShowDialog()

        'Load list view again
        Load_ListView1()
    End Sub

    Private Sub ListView1_Click(sender As Object, e As EventArgs) Handles ListView1.Click
        ViewToolStripMenuItem.Enabled = True
    End Sub

    Private Sub ListView1_DoubleClick(sender As Object, e As EventArgs) Handles ListView1.DoubleClick

        'Open View
        ViewToolStripMenuItem_Click(sender, e)
    End Sub

    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged

    End Sub

    
End Class