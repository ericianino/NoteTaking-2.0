﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmView
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmView))
        Me.txtNote = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtType = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblDateOfNote = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'txtNote
        '
        Me.txtNote.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.txtNote.Enabled = False
        Me.txtNote.Location = New System.Drawing.Point(86, 87)
        Me.txtNote.MaxLength = 300
        Me.txtNote.Multiline = True
        Me.txtNote.Name = "txtNote"
        Me.txtNote.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtNote.Size = New System.Drawing.Size(370, 96)
        Me.txtNote.TabIndex = 20
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(10, 90)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(33, 13)
        Me.Label4.TabIndex = 19
        Me.Label4.Text = "Note:"
        '
        'txtType
        '
        Me.txtType.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.txtType.Enabled = False
        Me.txtType.Location = New System.Drawing.Point(86, 49)
        Me.txtType.MaxLength = 25
        Me.txtType.Name = "txtType"
        Me.txtType.Size = New System.Drawing.Size(206, 20)
        Me.txtType.TabIndex = 18
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(10, 52)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(72, 13)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "Type of Note:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(10, 13)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(71, 13)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "Date of Note:"
        '
        'lblDateOfNote
        '
        Me.lblDateOfNote.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblDateOfNote.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDateOfNote.Enabled = False
        Me.lblDateOfNote.Location = New System.Drawing.Point(86, 13)
        Me.lblDateOfNote.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDateOfNote.Name = "lblDateOfNote"
        Me.lblDateOfNote.Size = New System.Drawing.Size(206, 21)
        Me.lblDateOfNote.TabIndex = 15
        Me.lblDateOfNote.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'frmView
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(468, 189)
        Me.Controls.Add(Me.txtNote)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtType)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblDateOfNote)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "frmView"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "View Note"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtNote As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtType As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lblDateOfNote As System.Windows.Forms.Label
End Class
