﻿Public Class frmMain

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click

        'Closing application
        Me.Close()
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Load_ListView1()
    End Sub

    Public Sub Load_ListView1()

        'Access Data Connection
        Dim AccessDataSet As New DataSet
        Dim AccessDataAdapter As OleDb.OleDbDataAdapter
        Dim sql As String
        Dim AccessConnection As New OleDb.OleDbConnection
        Dim strEmpty As String = ""
        AccessConnection.ConnectionString = AccessConnectionString

        ' number of columns in the list view
        Dim strItemcoll(3) As String

        ChangeToolStripMenuItem.Enabled = False
        RemoveToolStripMenuItem.Enabled = False
        ViewToolStripMenuItem.Enabled = False

        ListView1.Items.Clear()
        ListView1.GridLines = True

        ' Select all notes

        sql = " SELECT * FROM Tab_Notes_Header"

        'Opening access database
        AccessConnection.Open()

        AccessDataAdapter = New OleDb.OleDbDataAdapter(sql, AccessConnection)
        AccessDataAdapter.Fill(AccessDataSet)

        'close the database connection
        AccessConnection.Close()

        ' Adding the items into the listview
        For i = 0 To AccessDataSet.Tables(0).Rows.Count - 1

            strItemcoll(0) = Format(CDate(AccessDataSet.Tables(0).Rows(i)(2).ToString()), "MM/dd/yyyy hh:mm:ss tt")
            strItemcoll(1) = AccessDataSet.Tables(0).Rows(i)(3).ToString()
            strItemcoll(2) = AccessDataSet.Tables(0).Rows(i)(1).ToString()

            'if date close do not add to list view. 
            If AccessDataSet.Tables(0).Rows(i)(4).ToString() = "" Then
                Dim lvi As New ListViewItem(strItemcoll)
                lvi.Tag = AccessDataSet.Tables(0).Rows(i)(0).ToString
                ListView1.Items.Add(lvi)
            End If

        Next

        'clean up
        AccessDataSet = Nothing
        AccessDataAdapter = Nothing
        AccessConnection = Nothing

    End Sub


    Private Sub AddToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddToolStripMenuItem.Click
        'Opening New note screen
        frmAdd.ShowDialog()

        'Reload Listview after add
        Load_ListView1()

    End Sub


    Private Sub RemoveToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RemoveToolStripMenuItem.Click

        Dim AccessDataSet As New DataSet
        Dim AccessDataAdapter As OleDb.OleDbDataAdapter
        Dim sql As String
        Dim AccessConnection As New OleDb.OleDbConnection
        Dim intNSAN As String
        AccessConnection.ConnectionString = AccessConnectionString

        ' assign Notes variables
        intNSAN = ListView1.FocusedItem.Tag

        'Record not in City Table - Prompt user if want proceed deleting records.
        If MessageBox.Show("Are you sure want to Delete?", "Delete Note", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = DialogResult.Yes Then

            ' open the database connection
            AccessConnection.Open()

            sql = "DELETE FROM Tab_Notes_Header Where NSAN = " & intNSAN

            AccessDataAdapter = New OleDb.OleDbDataAdapter(sql, AccessConnection)
            AccessDataAdapter.Fill(AccessDataSet)

            ' close database connection
            AccessConnection.Close()

            'Confirmation of Delete
            MsgBox("Deleted!", MessageBoxButtons.OK, "Delete County Record")

            'Reload County_lisview after deleting. 
            Load_ListView1()

        End If

    End Sub

    Private Sub ListView1_Click(sender As Object, e As EventArgs) Handles ListView1.Click

        'Enabling Buttons
        ChangeToolStripMenuItem.Enabled = True
        RemoveToolStripMenuItem.Enabled = True
        ViewToolStripMenuItem.Enabled = True

    End Sub

    Private Sub ChangeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ChangeToolStripMenuItem.Click

        'sending SAN to Edit
        frmEdit.intNSAN = CInt(ListView1.FocusedItem.Tag.ToString)

        'openind Edit Form. 
        frmEdit.ShowDialog()

        'Load list view again
        Load_ListView1()

    End Sub

    Private Sub ViewToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ViewToolStripMenuItem.Click

        'sending SAN to View
        frmView.intNSAN = CInt(ListView1.FocusedItem.Tag.ToString)

        'Open View Form. 
        frmView.ShowDialog()

        'Load list view again
        Load_ListView1()
    End Sub

    Private Sub ToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem1.Click

        'Open View Form. 
        frmViewAll.ShowDialog()

    End Sub
End Class
