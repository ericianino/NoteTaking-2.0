﻿Public Class frmCalendar

    Public PassedInDate As Date  'date passed into this Calendar
    Public PassedOutDate As String 'date string passed out from this Calendar

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub


    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        ' Pass the date back to the calling proceedure
        ' capture the date selected
        PassedOutDate = CStr(MonthCalendar1.SelectionStart)

        Me.Close()

    End Sub

    Private Sub frmCalendar_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ' handles a blank date pased in from the calling form
        On Error Resume Next

        ' sets the calendar date to the date passed in 
        If IsDate(PassedInDate) Then
            MonthCalendar1.SetDate(PassedInDate)
        End If

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'pass a null back to the calling form to remove the date.
        PassedOutDate = ""
        Me.Close()
    End Sub

    Private Sub MonthCalendar1_DateChanged(sender As Object, e As DateRangeEventArgs) Handles MonthCalendar1.DateChanged

    End Sub
End Class